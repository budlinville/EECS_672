// Window.h

#ifndef WINDOW_H
#define WINDOW_H

#include <GL/gl.h>

#include "ModelView.h"
#include "ShaderIF.h"
#include "GLFWController.h"
#include "Block.h"
#include "SceneElement.h"
#include "PhongMaterial.h"

class Window : public SceneElement
{
public:
	Window(ShaderIF* sIF, PhongMaterial& matl, float cx, float cy, float cz, float l, float t);
	virtual ~Window();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimitsF) const;
	void render();

	bool handleCommand(unsigned char anASCIIChar, double ldsX, double ldsY);
private:
	GLuint vao[1];
	GLuint vbo[2];

	float xmin, xmax, ymin, ymax, zmin, zmax;
	float length, trimWidth;

	float kd[3];
	float ka[3];
	float ambientStrength[3];

	//Block *trim[2];

	void defineWindow();
	void renderWindow();
};

#endif
