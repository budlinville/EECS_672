// Controller.h - An Abstract base Class for a Controller (in Model-View-Controller sense)

#ifndef CONTROLLER_SUBCLASS_H
#define CONTROLLER_SUBCLASS_H

#include "GLFWController.h"
#include "ShaderIF.h"
#include <iostream>
#include <stdlib.h>
#include <string>
#include <vector>

class ModelView;

class ControllerSubclass : public GLFWController {
private:
  //shaderIF* sIF;
  bool dt;

  //void drawAllObjects();
  void drawAllOpaqueObjects();
  void drawAllTranslucentObjects();

public:
  ControllerSubclass(const std::string& windowTitle, int rcFlags);
  void handleDisplay();
  bool drawingTrans();
  //void recordShaderIF(shaderIF* sIF);
};

#endif
