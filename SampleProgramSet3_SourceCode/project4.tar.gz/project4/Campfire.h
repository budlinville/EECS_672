// Campfire.h

#ifndef Campfire_H
#define Campfire_H

#include "SceneElement.h"
#include "ShaderIF.h"
#include "../mvcutil/BasicShape.h"
#include "../mvcutil/BasicShapeRenderer.h"
#include "SceneElement.h"
#include "PhongMaterial.h"

class Campfire : public SceneElement
{
public:
	Campfire(ShaderIF* sIF, PhongMaterial& matl, float cx, float cy, float cz, float l);
	virtual ~Campfire();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimitsF) const;
	void render();

	bool handleCommand(unsigned char anASCIIChar, double ldsX, double ldsY);
private:
	// IMPORTANT NOTE:
	// The ShaderIF and kd (and other) material properties will be
	// stored with the SceneElement piece of this object instance.
	// You only need add instance variables here that are unique
	// to the new subclass you are creating.
	float xmin, xmax, ymin, ymax, zmin, zmax;
	float logRadius; float logLength;

	BasicShapeRenderer *log1Renderer;
	BasicShapeRenderer *log2Renderer;
	BasicShapeRenderer *log3Renderer;
	BasicShapeRenderer *log4Renderer;
	BasicShapeRenderer *log5Renderer;
	BasicShapeRenderer *log6Renderer;
	BasicShapeRenderer *log7Renderer;
	BasicShape *log1;
	BasicShape *log2;
	BasicShape *log3;
	BasicShape *log4;
	BasicShape *log5;
	BasicShape *log6;
	BasicShape *log7;

	void defineCampfire();
	void renderCampfire();
};

#endif
