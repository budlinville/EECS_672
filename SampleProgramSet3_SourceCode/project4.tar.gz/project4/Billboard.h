// Billboard.h

#ifndef Billboard_H
#define Billboard_H

#include "ModelView.h"
#include "ShaderIF.h"
#include "GLFWController.h"
#include "SceneElement.h"
#include "PhongMaterial.h"
#include "../mvcutil/BasicShape.h"
#include "../mvcutil/BasicShapeRenderer.h"

class Billboard : public SceneElement
{
public:
	Billboard(ShaderIF* sIF, PhongMaterial& matl, float cx, float cy, float cz, float h, const char* texImageSource);
	virtual ~Billboard();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimitsF) const;
	void render();

	bool handleCommand(unsigned char anASCIIChar, double ldsX, double ldsY);
private:
	float xmin, xmax, ymin, ymax, zmin, zmax;
	GLuint vao[1];
	GLuint vbo[3];

	float poleRadius, poleHeight, poleXCenter, poleZCenter;

	BasicShapeRenderer *poleRenderer;
	BasicShapeRenderer *boardRenderer;
	BasicShapeRenderer *baseRenderer;
	BasicShapeRenderer *poleBaseRenderer;
	BasicShape *pole;
	BasicShape *board;
	BasicShape *base;
	BasicShape *poleBase;

	void defineBillboard();
	void renderBillboard();
};

#endif
