// Lamp.h

#ifndef Lamp_H
#define Lamp_H

#include "SceneElement.h"
#include "ShaderIF.h"
#include "../mvcutil/BasicShape.h"
#include "../mvcutil/BasicShapeRenderer.h"
#include "SceneElement.h"
#include "PhongMaterial.h"

class Lamp : public SceneElement
{
public:
	Lamp(ShaderIF* sIF, PhongMaterial& matl, float x, float y, float z, float h, float r);
	virtual ~Lamp();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimitsF) const;
	void render();
private:
	// IMPORTANT NOTE:
	// The ShaderIF and kd (and other) material properties will be
	// stored with the SceneElement piece of this object instance.
	// You only need add instance variables here that are unique
	// to the new subclass you are creating.
	float xmin, xmax, ymin, ymax, zmin, zmax;
	float poleRadius, poleHeight, poleXCenter, poleZCenter;

	BasicShapeRenderer *myRenderer;
	BasicShape *pole;
	BasicShape *bulb;

	void defineLamp();
	void renderLamp();
};

#endif
