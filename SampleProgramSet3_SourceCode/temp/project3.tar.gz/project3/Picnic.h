// Picnic.h

#ifndef Picnic_H
#define Picnic_H

#include "SceneElement.h"
#include "ShaderIF.h"
#include "../mvcutil/BasicShape.h"
#include "../mvcutil/BasicShapeRenderer.h"
#include "SceneElement.h"
#include "PhongMaterial.h"

class Picnic : public SceneElement
{
public:
	Picnic(ShaderIF* sIF, PhongMaterial& matl, float cx, float cy, float cz, float l, float h);
	virtual ~Picnic();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimitsF) const;
	void render();
private:
	// IMPORTANT NOTE:
	// The ShaderIF and kd (and other) material properties will be
	// stored with the SceneElement piece of this object instance.
	// You only need add instance variables here that are unique
	// to the new subclass you are creating.
	float xmin, xmax, ymin, ymax, zmin, zmax;
	float length; float height;

	BasicShapeRenderer *myRenderer;
	//BasicShape *table;
	BasicShape *tableLeg1;
	/*
	BasicShape *tableLeg2;
	BasicShape *tableLeg3;
	BasicShape *tableLeg4;

	BasicShape *bench;
	BasicShape *benchLeg1;
	BasicShape *benchLeg2;
	BasicShape *benchLeg3;
	BasicShape *benchLeg4;
	*/
	void definePicnic();
	void renderPicnic();
};

#endif
