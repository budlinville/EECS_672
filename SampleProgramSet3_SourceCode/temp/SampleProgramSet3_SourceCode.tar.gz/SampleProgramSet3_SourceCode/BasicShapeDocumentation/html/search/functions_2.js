var searchData=
[
  ['getalwaysgeneratepervertexnormals',['getAlwaysGeneratePerVertexNormals',['../classBasicShape.html#afc8e7b081c645e8a643c094a2a2fa5ea',1,'BasicShape']]],
  ['getdrawarraysdata',['getDrawArraysData',['../classBasicShape.html#ac96af5a4a10fc5b0b0f75fcac1639e05',1,'BasicShape']]],
  ['getindexlist',['getIndexList',['../classBasicShape.html#aeb0be5dbb686d2c035507df2da9aea51',1,'BasicShape']]],
  ['getmcboundingbox',['getMCBoundingBox',['../classBasicShape.html#a1ab1ededb0c494046f2a70b1c5b04bca',1,'BasicShape::getMCBoundingBox()'],['../classBasicShapeRenderer.html#adaa972b9ccf4f88bbc10a83c953a61f2',1,'BasicShapeRenderer::getMCBoundingBox()']]],
  ['getnormals',['getNormals',['../classBasicShape.html#a8ce54bb50dae050db0379f5e02c20de9',1,'BasicShape']]],
  ['getnumdrawarrayscalls',['getNumDrawArraysCalls',['../classBasicShape.html#afa0e1bb329f91bae0571ee9df61f07a0',1,'BasicShape']]],
  ['getnumindexlists',['getNumIndexLists',['../classBasicShape.html#a4e1cd5d6f38092111243df1135f5e548',1,'BasicShape']]],
  ['getnumpoints',['getNumPoints',['../classBasicShape.html#a6c813f1b82d4cb69ea26270a75ba371b',1,'BasicShape']]],
  ['getpointcoords',['getPointCoords',['../classBasicShape.html#a761b92943bb56e3d6f57cf3c5d4142a3',1,'BasicShape']]],
  ['gettexturecoords',['getTextureCoords',['../classBasicShape.html#ab6abe53ddd95e61e4f73013c407a4caa',1,'BasicShape']]]
];
