var searchData=
[
  ['makeblock',['makeBlock',['../classBasicShape.html#a3f58b0e2110450d60940da6e09b83036',1,'BasicShape']]],
  ['makeboundedcone',['makeBoundedCone',['../classBasicShape.html#a005a529d7f754964285e3921b0f51055',1,'BasicShape']]],
  ['makeboundedcylinder',['makeBoundedCylinder',['../classBasicShape.html#af9c0d5466c82a22c0abf472bb7a65f61',1,'BasicShape']]],
  ['makesphere',['makeSphere',['../classBasicShape.html#a4e8028ce3c87a60ae7c2f6f38dcb2065',1,'BasicShape']]]
];
